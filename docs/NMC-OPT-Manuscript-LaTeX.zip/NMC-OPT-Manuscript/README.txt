NMC-OPT: Intelligent Compiler Optimization for Near-Memory Computing
IEEE Access-style manuscript (LaTeX source)
=====================================================================

HOW TO USE ON OVERLEAF
1. Overleaf -> New Project -> Upload Project -> select this ZIP.
2. Menu -> Compiler: pdfLaTeX (default). TeX Live: 2020 or newer.
3. Main document: main.tex  -> click Recompile.
   (Compile twice if you edit, so cross-references update.)

PROJECT STRUCTURE
main.tex                    Preamble, title block, abstract, includes
sections/01_introduction.tex
sections/02_related_work.tex
sections/03_proposed_system.tex   (architecture, equations, algorithms, listings)
sections/04_results.tex           (tables 2-4, figures 6-14, discussion)
sections/05_conclusion_backmatter.tex
sections/06_references.tex        (30 references, thebibliography)
sections/07_biographies.tex       (author photos + biographies page)
figures/   fig01 ... fig14 (JPG)  -> FIGURE 1 ... FIGURE 14
photos/    5 author photos
logo/      IEEE Access logos used in header (small) and first page (large)

NOTES
* Only standard packages are used (no external .cls/.sty needed).
* Tables 1-4, Algorithms 1-2, equations (1)-(9) and code listings are
  real LaTeX (not images) so they are fully editable.
* Figures 1-14 are the images from the final manuscript.
* Biography page: left column = Nikhit, Metta, Govind;
  right column = Dhayapule, Aahaan.
